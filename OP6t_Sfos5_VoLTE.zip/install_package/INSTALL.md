# VoLTE for OnePlus 6T on Sailfish OS

Enables VoLTE (Voice over LTE) calling with working audio on OnePlus 6T
running Sailfish OS 5.0.0.67.

Tested with Telia Norway. Should work with other carriers that support VoLTE
on OnePlus 6T, but only Telia Norway has been verified.

## What's in this package

```
install_package/
  install.sh                  - Automated install script (run on phone)
  uninstall.sh                - Reverts all changes
  config/
    binder.conf               - ofono configuration for dual-SIM + IMS
    arm_droid_card_custom.pa  - PulseAudio droid card with realcall quirk
    volte_voicecall.conf      - PulseAudio audio routing for VoLTE calls
  ofono-binder-plugin/        - Patched binder plugin source (v1.1.22)
  ofono-binder-plugin-ext-qti/  - Patched QTI IMS extension source
  patches/
    0001-ofono-binder-plugin-fix-volte-gprs-attach-and-data-loop.patch
    0002-ofono-binder-plugin-ext-qti-fix-volte-dial-and-crashes.patch
```

## What the patches fix

**ofono-binder-plugin** (patch 0001):
- GPRS attach was blocked by data permission checks, preventing IMS registration
- SET_PREFERRED_DATA_MODEM retried infinitely on failure, causing SEGV crash

**ofono-binder-plugin-ext-qti** (patch 0002):
- VoLTE dial request was missing call details and PS domain, causing network
  rejection after 32 seconds (cause 248)
- Signal handlers weren't disconnected on cleanup, causing use-after-free SEGV
- NULL pointer dereference in IMS registration status handler
- Memory leaks in slot cleanup

**PulseAudio audio routing** (volte_voicecall.conf):
- Default `voicecall` profile doesn't open the VoiceMMode1 PCM device on SDM845
- The `voicecall-voicemmode1` profile correctly opens the voice audio path
- Without this fix, calls connect but have no audio in either direction

## Prerequisites

- OnePlus 6T with Sailfish OS 5.0.0.67
- Developer mode enabled (Settings > System > Developer tools)
- SSH access (shown in Developer tools settings)
- A working SIM card with VoLTE-capable carrier

## Quick install

From your computer:

```bash
# 1. Copy the package to the phone
scp -r install_package defaultuser@PHONE_IP:/home/defaultuser/

# 2. SSH into the phone
ssh defaultuser@PHONE_IP

# 3. Become root
devel-su
# Enter your developer mode password

# 4. Run the installer
cd /home/defaultuser/install_package
chmod +x install.sh
./install.sh
```

The script will:
1. Back up current config to `/home/defaultuser/volte_backup/`
2. Install build dependencies (gcc, glib2-devel, libgbinder-devel, etc.)
3. Build both plugins from source on the device
4. Install the plugins to `/usr/lib64/ofono/plugins/`
5. Disable the old RIL plugins (renamed to `.bak`)
6. Install ofono and PulseAudio configuration files
7. Restart ofono and PulseAudio
8. Show IMS registration status

After the script finishes, make a phone call to verify VoLTE and audio work.

## Manual install

If you prefer to install step by step, or if the script fails.

### 1. Install build dependencies

On the phone as root:

```bash
zypper install gcc make pkgconfig glib2-devel libgbinder-devel \
    libgbinder-radio-devel ofono-devel libmce-glib-devel
```

### 2. Build ofono-binder-plugin

```bash
cd /home/defaultuser/install_package/ofono-binder-plugin
make clean
make release
```

Install:

```bash
cp build/release/binderplugin.so /usr/lib64/ofono/plugins/
cp lib/build/release/libofonobinderpluginext.so.1.1.22 /usr/lib64/
ln -sf libofonobinderpluginext.so.1.1.22 /usr/lib64/libofonobinderpluginext.so.1
ln -sf libofonobinderpluginext.so.1 /usr/lib64/libofonobinderpluginext.so
```

### 3. Build ofono-binder-plugin-ext-qti

```bash
cd /home/defaultuser/install_package/ofono-binder-plugin-ext-qti
mkdir -p /tmp/qti-build/release

CFLAGS="-fPIC -fvisibility=hidden -Wall -O2 \
    $(pkg-config --cflags libgbinder-radio libgbinder libglibutil gobject-2.0 glib-2.0) \
    -I/home/defaultuser/install_package/ofono-binder-plugin/lib/include"

LDFLAGS="$(pkg-config --libs libgbinder-radio libgbinder libglibutil gobject-2.0 glib-2.0) \
    -L/usr/lib64 -lofonobinderpluginext"

for f in qti_ext qti_ims qti_ims_call qti_ims_sms qti_plugin qti_radio_ext qti_slot; do
    gcc $CFLAGS -c src/$f.c -o /tmp/qti-build/release/$f.o
done

gcc -shared /tmp/qti-build/release/*.o $LDFLAGS \
    -o /tmp/qti-build/release/qtibinderpluginext.so
```

Install:

```bash
cp /tmp/qti-build/release/qtibinderpluginext.so /usr/lib64/ofono/plugins/
```

### 4. Disable conflicting plugins

```bash
mv /usr/lib64/ofono/plugins/rilplugin.so /usr/lib64/ofono/plugins/rilplugin.so.bak
mv /usr/lib64/ofono/plugins/rilbinderplugin.so /usr/lib64/ofono/plugins/rilbinderplugin.so.bak
rm -f /etc/ofono/binder.d/dual-sim.conf
mv /etc/ofono/ril_subscription.conf /etc/ofono/ril_subscription.conf.bak
```

### 5. Install configuration files

```bash
# ofono config
cp config/binder.conf /etc/ofono/binder.conf

# PulseAudio droid card (enables realcall quirk)
cp config/arm_droid_card_custom.pa /etc/pulse/arm_droid_card_custom.pa

# PulseAudio VoLTE audio routing (critical for call audio)
mkdir -p /etc/pulse/xpolicy.conf.d
cp config/volte_voicecall.conf /etc/pulse/xpolicy.conf.d/volte_voicecall.conf
```

### 6. Restart services

```bash
rm -rf /var/lib/ofono/*
systemctl restart ofono
killall pulseaudio    # auto-respawns
```

### 7. Verify

```bash
# Check ofono is running
systemctl status ofono

# Check IMS registration (wait ~5 seconds after restart)
dbus-send --system --print-reply --dest=org.ofono \
    /ril_0 org.ofono.IpMultimediaSystem.GetProperties
```

You should see:
- `Registered = true`
- `VoiceCapable = true`
- `SmsCapable = true`

Make a phone call to confirm audio works in both directions.

## Uninstall

```bash
ssh defaultuser@PHONE_IP
devel-su
cd /home/defaultuser/install_package
chmod +x uninstall.sh
./uninstall.sh
```

This restores the original RIL plugins and configs from backup. After
uninstalling, voice calls will only work on 2G/3G networks.

## Troubleshooting

### ofono crashes (SEGV)

Check for conflicting config files:

```bash
ls /etc/ofono/binder.d/
cat /etc/ofono/ril_subscription.conf 2>/dev/null
```

Remove any duplicate slot definitions. The `binder.d/dual-sim.conf` file is a
common cause - delete it if present.

### IMS not registering

Run ofono in debug mode:

```bash
systemctl stop ofono
/usr/sbin/ofonod -n -d 2>&1 | grep -iE "ims|qti|gprs|attach"
```

Look for `ims_state` values:
- `0` = NOT_REGISTERED - IMS APN may not be activating
- `1` = REGISTERING - in progress, wait
- `2` = REGISTERING (with network info)
- `3` = REGISTERED - VoLTE ready

If stuck at 0, check that your carrier provides an IMS APN and that data
features are enabled in binder.conf.

### Call connects but no audio

Verify PulseAudio config is installed:

```bash
cat /etc/pulse/xpolicy.conf.d/volte_voicecall.conf
cat /etc/pulse/arm_droid_card_custom.pa
```

During an active call, check the droid card profile:

```bash
pactl list cards | grep -A5 "droid_card"
```

It should show `voicecall-voicemmode1` as the active profile during a call.
If it shows `voicecall` instead, the volte_voicecall.conf is not being loaded.

Check that PulseAudio was restarted after installing the config:

```bash
killall pulseaudio
# Wait 2 seconds for auto-respawn
pactl list cards short
```

### Call rejected (cause 248)

This means the network rejected the VoLTE call setup. Verify the QTI plugin
is loaded:

```bash
journalctl -u ofono | grep -i qti
```

You should see it connecting to `vendor.qti.hardware.radio.ims@1.2::IImsRadio`.

### View logs

```bash
# Recent ofono logs
journalctl -u ofono -n 100

# Live ofono debug
systemctl stop ofono
/usr/sbin/ofonod -n -d 2>&1 | tee /tmp/ofono_debug.log

# PulseAudio logs
journalctl --user -u pulseaudio -n 50
```

## Configuration details

### binder.conf

- `extPlugin = qti` - loads the QTI IMS extension for Qualcomm IMS HAL
- `radioInterface = 1.2` - Radio HAL 1.2 (required for IMS indications)
- `SetRadioCapability = off` - prevents radio capability loop on dual-SIM
- `enabledFeatures = ims` - enables IMS/VoLTE support
- `disableFeatures = cbs` - disables Cell Broadcast (prevents infinite loop)
- Both slots must be configured even with one SIM (prevents data manager crash)

### arm_droid_card_custom.pa

- `quirks=+realcall` - enables real hardware voice call audio path instead of
  software mixing through PulseAudio

### volte_voicecall.conf

- Overrides PulseAudio card profile for all voice call device types
- Uses `voicecall-voicemmode1` instead of default `voicecall`
- On SDM845, `voicecall-voicemmode1` opens PCM device 2 (VoiceMMode1),
  which is the hardware voice audio path through the Qualcomm ADSP
- Covers: earpiece, speaker (ihf), headset, headphone, lineout, BT HSP, BT HFP

## OS update warning

Sailfish OS updates may overwrite these files:
- `/usr/lib64/ofono/plugins/binderplugin.so`
- `/usr/lib64/ofono/plugins/qtibinderpluginext.so`
- `/etc/pulse/arm_droid_card_custom.pa`

After an OS update, re-run `./install.sh` to restore VoLTE.

The files in `/etc/ofono/binder.conf` and `/etc/pulse/xpolicy.conf.d/` are
usually preserved across updates.

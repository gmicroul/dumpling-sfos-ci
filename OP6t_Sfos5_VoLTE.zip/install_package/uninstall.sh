#!/bin/bash
#
# VoLTE Uninstall Script for OnePlus 6T (Sailfish OS 5.0)
#
# Reverts all VoLTE changes and restores the original setup.
# Must be run ON THE PHONE as root (devel-su).
#

set -e

BACKUP_DIR="/home/defaultuser/volte_backup"

echo "============================================"
echo "  VoLTE Uninstall for OnePlus 6T"
echo "============================================"
echo ""

if [ "$(id -u)" != "0" ]; then
    echo "ERROR: Must be run as root. Use: devel-su"
    exit 1
fi

# --- Restore original ofono plugins ---

echo "[1/5] Restoring original ofono plugins..."

if [ -f /usr/lib64/ofono/plugins/rilplugin.so.bak ]; then
    mv /usr/lib64/ofono/plugins/rilplugin.so.bak /usr/lib64/ofono/plugins/rilplugin.so
    echo "  Restored rilplugin.so"
fi

if [ -f /usr/lib64/ofono/plugins/rilbinderplugin.so.bak ]; then
    mv /usr/lib64/ofono/plugins/rilbinderplugin.so.bak /usr/lib64/ofono/plugins/rilbinderplugin.so
    echo "  Restored rilbinderplugin.so"
fi

# --- Remove VoLTE plugins ---

echo ""
echo "[2/5] Removing VoLTE plugins..."

if [ -f /usr/lib64/ofono/plugins/qtibinderpluginext.so ]; then
    rm /usr/lib64/ofono/plugins/qtibinderpluginext.so
    echo "  Removed qtibinderpluginext.so"
fi

# --- Restore original configs ---

echo ""
echo "[3/5] Restoring original configs..."

if [ -f /etc/ofono/ril_subscription.conf.bak ]; then
    mv /etc/ofono/ril_subscription.conf.bak /etc/ofono/ril_subscription.conf
    echo "  Restored ril_subscription.conf"
fi

if [ -d "$BACKUP_DIR" ]; then
    if [ -f "$BACKUP_DIR/binder.conf" ]; then
        cp "$BACKUP_DIR/binder.conf" /etc/ofono/binder.conf
        echo "  Restored binder.conf from backup"
    fi
    if [ -f "$BACKUP_DIR/arm_droid_card_custom.pa" ]; then
        cp "$BACKUP_DIR/arm_droid_card_custom.pa" /etc/pulse/arm_droid_card_custom.pa
        echo "  Restored arm_droid_card_custom.pa from backup"
    fi
fi

# --- Remove VoLTE audio config ---

echo ""
echo "[4/5] Removing VoLTE audio config..."

if [ -f /etc/pulse/xpolicy.conf.d/volte_voicecall.conf ]; then
    rm /etc/pulse/xpolicy.conf.d/volte_voicecall.conf
    echo "  Removed volte_voicecall.conf"
fi

# --- Restart services ---

echo ""
echo "[5/5] Restarting services..."

rm -rf /var/lib/ofono/*
systemctl restart ofono
echo "  Restarted ofono"

killall pulseaudio 2>/dev/null || true
echo "  Restarted PulseAudio"

echo ""
echo "============================================"
echo "  Uninstall complete."
echo ""
echo "  The phone is restored to its original"
echo "  (non-VoLTE) configuration."
echo ""
echo "  Note: Voice calls will only work on"
echo "  2G/3G networks after this."
echo "============================================"

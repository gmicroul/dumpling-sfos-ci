#!/bin/bash
#
# VoLTE Installation Script for OnePlus 6T (Sailfish OS 5.0)
#
# Enables VoLTE calling with working audio on OnePlus 6T.
# Tested on Sailfish OS 5.0.0.67 with Telia Norway.
#
# This script must be run ON THE PHONE as root (devel-su).
#
# What it does:
#   1. Installs build dependencies
#   2. Builds patched ofono-binder-plugin (GPRS attach + data loop fixes)
#   3. Builds patched ofono-binder-plugin-ext-qti (VoLTE dial + crash fixes)
#   4. Disables conflicting old RIL plugins
#   5. Installs ofono binder configuration
#   6. Installs PulseAudio configs for VoLTE audio routing
#   7. Restarts ofono and PulseAudio
#
# Usage:
#   scp -r install_package defaultuser@<phone-ip>:/home/defaultuser/
#   ssh defaultuser@<phone-ip>
#   devel-su
#   cd /home/defaultuser/install_package
#   chmod +x install.sh && ./install.sh
#

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKUP_DIR="/home/defaultuser/volte_backup"

echo "============================================"
echo "  VoLTE Install for OnePlus 6T (SDM845)"
echo "  Sailfish OS 5.0"
echo "============================================"
echo ""

# --- Preflight checks ---

if [ "$(id -u)" != "0" ]; then
    echo "ERROR: Must be run as root. Use: devel-su"
    exit 1
fi

if [ ! -f /etc/sailfish-release ]; then
    echo "ERROR: Must be run on a Sailfish OS device."
    exit 1
fi

if [ ! -d "$SCRIPT_DIR/ofono-binder-plugin/src" ]; then
    echo "ERROR: ofono-binder-plugin source not found in $SCRIPT_DIR"
    exit 1
fi

if [ ! -d "$SCRIPT_DIR/ofono-binder-plugin-ext-qti/src" ]; then
    echo "ERROR: ofono-binder-plugin-ext-qti source not found in $SCRIPT_DIR"
    exit 1
fi

# --- Create backup ---

echo "[1/9] Backing up current configuration..."
mkdir -p "$BACKUP_DIR"

for f in /etc/ofono/binder.conf \
         /etc/ofono/ril_subscription.conf \
         /etc/pulse/arm_droid_card_custom.pa; do
    if [ -f "$f" ]; then
        cp "$f" "$BACKUP_DIR/" 2>/dev/null || true
        echo "  Backed up $f"
    fi
done

# Save list of original plugins for uninstall
ls /usr/lib64/ofono/plugins/*.so 2>/dev/null > "$BACKUP_DIR/original_plugins.list" || true
echo "  Backups saved to $BACKUP_DIR/"

# --- Install build dependencies ---

echo ""
echo "[2/9] Installing build dependencies..."
zypper install -y gcc make pkgconfig \
    glib2-devel libgbinder-devel libgbinder-radio-devel \
    ofono-devel libmce-glib-devel 2>&1 | tail -3 || true

# --- Build ofono-binder-plugin ---

echo ""
echo "[3/9] Building ofono-binder-plugin..."
cd "$SCRIPT_DIR/ofono-binder-plugin"
make clean 2>/dev/null || true
make release

# --- Install ofono-binder-plugin ---

echo ""
echo "[4/9] Installing ofono-binder-plugin..."
cp build/release/binderplugin.so /usr/lib64/ofono/plugins/
cp lib/build/release/libofonobinderpluginext.so.1.1.22 /usr/lib64/
ln -sf libofonobinderpluginext.so.1.1.22 /usr/lib64/libofonobinderpluginext.so.1
ln -sf libofonobinderpluginext.so.1 /usr/lib64/libofonobinderpluginext.so
echo "  Installed binderplugin.so"
echo "  Installed libofonobinderpluginext.so"

# --- Build ofono-binder-plugin-ext-qti ---

echo ""
echo "[5/9] Building ofono-binder-plugin-ext-qti..."
cd "$SCRIPT_DIR/ofono-binder-plugin-ext-qti"
mkdir -p /tmp/qti-build/release

QTI_CFLAGS="-fPIC -fvisibility=hidden -Wall -O2 \
    $(pkg-config --cflags libgbinder-radio libgbinder libglibutil gobject-2.0 glib-2.0) \
    -I$SCRIPT_DIR/ofono-binder-plugin/lib/include"
QTI_LDFLAGS="$(pkg-config --libs libgbinder-radio libgbinder libglibutil gobject-2.0 glib-2.0) \
    -L/usr/lib64 -lofonobinderpluginext"

for f in qti_ext qti_ims qti_ims_call qti_ims_sms qti_plugin qti_radio_ext qti_slot; do
    gcc $QTI_CFLAGS -c src/$f.c -o /tmp/qti-build/release/$f.o
done
gcc -shared /tmp/qti-build/release/*.o $QTI_LDFLAGS -o /tmp/qti-build/release/qtibinderpluginext.so

echo ""
echo "[6/9] Installing ofono-binder-plugin-ext-qti..."
cp /tmp/qti-build/release/qtibinderpluginext.so /usr/lib64/ofono/plugins/
echo "  Installed qtibinderpluginext.so"

# --- Disable conflicting plugins and configs ---

echo ""
echo "[7/9] Disabling conflicting plugins and configs..."

if [ -f /usr/lib64/ofono/plugins/rilplugin.so ] && \
   [ ! -f /usr/lib64/ofono/plugins/rilplugin.so.bak ]; then
    mv /usr/lib64/ofono/plugins/rilplugin.so /usr/lib64/ofono/plugins/rilplugin.so.bak
    echo "  Disabled rilplugin.so"
fi

if [ -f /usr/lib64/ofono/plugins/rilbinderplugin.so ] && \
   [ ! -f /usr/lib64/ofono/plugins/rilbinderplugin.so.bak ]; then
    mv /usr/lib64/ofono/plugins/rilbinderplugin.so /usr/lib64/ofono/plugins/rilbinderplugin.so.bak
    echo "  Disabled rilbinderplugin.so"
fi

if [ -f /etc/ofono/binder.d/dual-sim.conf ]; then
    rm -f /etc/ofono/binder.d/dual-sim.conf
    echo "  Removed conflicting dual-sim.conf"
fi

if [ -f /etc/ofono/ril_subscription.conf ]; then
    mv /etc/ofono/ril_subscription.conf /etc/ofono/ril_subscription.conf.bak
    echo "  Disabled ril_subscription.conf"
fi

# --- Install configuration files ---

echo ""
echo "[8/9] Installing configuration files..."

# ofono binder config
cp "$SCRIPT_DIR/config/binder.conf" /etc/ofono/binder.conf
echo "  Installed /etc/ofono/binder.conf"

# PulseAudio droid card config (realcall quirk for voice PCM)
cp "$SCRIPT_DIR/config/arm_droid_card_custom.pa" /etc/pulse/arm_droid_card_custom.pa
echo "  Installed /etc/pulse/arm_droid_card_custom.pa"

# PulseAudio VoLTE audio routing (voicecall-voicemmode1 profile)
mkdir -p /etc/pulse/xpolicy.conf.d
cp "$SCRIPT_DIR/config/volte_voicecall.conf" /etc/pulse/xpolicy.conf.d/volte_voicecall.conf
echo "  Installed /etc/pulse/xpolicy.conf.d/volte_voicecall.conf"

# --- Restart services ---

echo ""
echo "[9/9] Restarting services..."

rm -rf /var/lib/ofono/*
systemctl restart ofono
echo "  Restarted ofono"

# Restart PulseAudio (runs as user nemo/defaultuser, not root)
killall pulseaudio 2>/dev/null || true
echo "  Restarted PulseAudio (will auto-respawn)"

# --- Verify ---

echo ""
echo "Waiting for IMS registration..."
sleep 5

echo ""
if systemctl is-active --quiet ofono; then
    echo "[OK] ofono is running"
else
    echo "[FAIL] ofono is not running"
    echo "  Check: journalctl -u ofono -n 50"
    exit 1
fi

echo ""
echo "IMS status:"
dbus-send --system --print-reply --dest=org.ofono \
    /ril_0 org.ofono.IpMultimediaSystem.GetProperties 2>/dev/null \
    || echo "  IMS interface not available yet. Wait a moment and run:"
echo ""
echo "  dbus-send --system --print-reply --dest=org.ofono /ril_0 org.ofono.IpMultimediaSystem.GetProperties"

echo ""
echo "============================================"
echo "  Installation complete!"
echo ""
echo "  If IMS shows Registered=true and"
echo "  VoiceCapable=true, VoLTE is working."
echo "  Make a phone call to verify audio."
echo ""
echo "  To uninstall: ./uninstall.sh"
echo "============================================"
